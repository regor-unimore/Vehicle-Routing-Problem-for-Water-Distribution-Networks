The instances are organised as follows:
- number of customers
- number of vehicles
- distance matrix
- value computed for Dmax(2), rounded down to the nearest unit
- value computed for Dmax(3), rounded down to the nearest unit ("n/a" if no feasible solution was found when solving the previous problem)
