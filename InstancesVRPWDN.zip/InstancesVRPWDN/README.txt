The instances are organized as follows:

- number of demand nodes of type I and II
- number of key centers
- number of vehicles
- array of service times
- traveling time matrix
- array of predecessor nodes
- array of successor nodes

Array of service times: the first node is the depot and its service time is set to zero.

Traveling time matrix: the first row gives the traveling time from the depot to the demand nodes. The matrix is symmetrical.

Array of predecessor nodes: we associate a predecessor node with each node. For all nodes of type II, their predecessor node is given, otherwise the corresponding value is set to zero.

Array of successor nodes: we associate a successor node with each node. For all nodes of type II, their successor node is given, otherwise the corresponding value is set to zero.
