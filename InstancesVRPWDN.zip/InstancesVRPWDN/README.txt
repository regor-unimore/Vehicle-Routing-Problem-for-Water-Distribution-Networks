The instances are organised as follows:
- number of demand nodes of type I and II
- number of key centers
- number of vehicles
- array of service times
- traveling time matrix
- array of predecessor nodes
- array of successor nodes

Array of service times: the first node is the depot and its service time is set to zero.

Travelling time matrix: the first row gives the travelling time from the depot to the demand nodes. The matrix is symmetrical.

Array of predecessor nodes: each node is associated with a predecessor node. For all nodes of type II, their predecessor node is given, otherwise the corresponding value is set to zero.

Array of successor nodes: each node is associated with a successor node. For all nodes of type II, their successor node is given, otherwise the corresponding value is set to zero.
